package edu.austincollege.acvote.vote.dao;

public class DuplicateVotingTokenException extends Exception {

	private static final long serialVersionUID = -7287506987514886450L;

	public DuplicateVotingTokenException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
