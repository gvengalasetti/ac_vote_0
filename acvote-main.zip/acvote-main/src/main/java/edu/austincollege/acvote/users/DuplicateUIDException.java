package edu.austincollege.acvote.users;

public class DuplicateUIDException extends Exception {

	public DuplicateUIDException(String message) {
		super(message);
	}
}
