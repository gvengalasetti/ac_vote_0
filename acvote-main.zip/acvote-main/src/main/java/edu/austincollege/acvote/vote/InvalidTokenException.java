package edu.austincollege.acvote.vote;

public class InvalidTokenException extends Exception {

	public InvalidTokenException(String message) {
		super(message);
	}
}
