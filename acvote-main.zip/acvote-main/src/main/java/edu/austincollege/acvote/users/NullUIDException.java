package edu.austincollege.acvote.users;

public class NullUIDException extends Exception {

	public NullUIDException(String message) {
		super(message);
	}

}
