This file is a placeholder to establish the home for JAVA SOURCE CODE.

UTILITY CLASSES

We ALSO use this file for additional relevant notes to developers.