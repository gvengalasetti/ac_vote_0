This file is a placeholder to establish the static home for...

CSS Stylesheets

We ALSO use this file for additional relevant notes to developers.