This file is a placeholder to establish the static home for...

Freemarker templates

We ALSO use this file for additional relevant notes to developers.

* organize using folders/packages corresponding to the functional subsystem.  